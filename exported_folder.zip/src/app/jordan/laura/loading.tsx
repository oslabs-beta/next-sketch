
  import React from 'react';
  
  const Loading = () => {
    return (
      <>
        {/* Your page content goes here */}
      </>
    );
  };
  
  export default Loading;
  