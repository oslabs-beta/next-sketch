import React from 'react';

const Route = () => {
  return <></>;
};

export default Route;
