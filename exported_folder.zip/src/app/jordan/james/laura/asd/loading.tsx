import React from 'react';

const Loading = () => {
  return <></>;
};

export default Loading;
