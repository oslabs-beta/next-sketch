
  import React from 'react';
  
  const Default = () => {
    return (
      <>
        {/* Your page content goes here */}
      </>
    );
  };
  
  export default Default;
  