
  import React from 'react';
  
  const Error = () => {
    return (
      <>
        {/* Your page content goes here */}
      </>
    );
  };
  
  export default Error;
  