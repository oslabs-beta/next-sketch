
  import React from 'react';
  
  const Layout = () => {
    return (
      <>
        {/* Your page content goes here */}
      </>
    );
  };
  
  export default Layout;
  