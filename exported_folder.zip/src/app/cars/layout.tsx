import React from 'react';

const Layout = () => {
  return (
    <>
      <div>
        <p></p>
      </div>
      <div></div>
    </>
  );
};

export default Layout;
