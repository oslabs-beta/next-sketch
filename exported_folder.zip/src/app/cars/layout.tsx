import React from 'react';
const Layout = () => {
  return (
    <>
      <div>
        <div>
          <img src=" " />
        </div>
        <p></p>
      </div>
      <form></form>
    </>
  );
};
export default Layout;
