import React from 'react';
const Error = () => {
  return <></>;
};
export default Error;
