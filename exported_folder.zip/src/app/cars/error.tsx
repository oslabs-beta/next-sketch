import React from 'react';

const Error = () => {
  return (
    <>
      <form></form>
    </>
  );
};

export default Error;
