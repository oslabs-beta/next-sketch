import React from 'react';
const Layout = () => {
  return <></>;
};
export default Layout;
