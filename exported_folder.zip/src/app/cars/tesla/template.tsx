import React from 'react';

const Template = () => {
  return <></>;
};

export default Template;
