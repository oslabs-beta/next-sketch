
  import React from 'react';
  
  const Template = () => {
    return (
      <>
        {/* Your page content goes here */}
      </>
    );
  };
  
  export default Template;
  