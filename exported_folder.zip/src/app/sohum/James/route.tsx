
  import React from 'react';
  
  const Route = () => {
    return (
      <>
        {/* Your page content goes here */}
      </>
    );
  };
  
  export default Route;
  